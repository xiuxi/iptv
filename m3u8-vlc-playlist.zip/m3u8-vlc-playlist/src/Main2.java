import java.io.File;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class Main2 {

	public static void main(String[] args) throws Exception {
		File baseDir = new File("C:\\workspace\\m3u8-vlc-playlist\\");
		File [] channels = new File(baseDir, "channels").listFiles();
		for (File channel : channels) {
			channel = new File("C:\\workspace\\m3u8-vlc-playlist\\一大波美国源.txt");
			List<String> lines = FileUtils.readLines(channel);
			for (int i = 0; i < lines.size(); i++) {
				String line = lines.get(i);
				if (1==1) {
					if (line.contains(",")) {
						String name = line.split(",")[0]+".bat";
						String url = line.split(",")[1];
						System.out.println("name="+name+" url="+url);
						
						
						
						try {
							FileUtils.write(new File(baseDir, "playlist\\"+name), 
									
									"taskkill /IM \"vlc.exe\" /F\r\n" + 
									"\"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe\" " + url +"\r\n");
						} catch (Exception e) {
							// TODO Auto-generated catch block
	//						e.printStackTrace();
						}
					}
					
//					System.out.println(line);
//					String title = lines.get(i-1);
//					if (title.contains(",")) {
//						title = title.substring(title.lastIndexOf(",")+1);
//					}
//					title = channel.getName().replace(".m3u", "_")+title+".bat";
//					System.out.println(title);
//					try {
//						FileUtils.write(new File(baseDir, "playlist\\"+title), 
//								
//								"taskkill /IM \"vlc.exe\" /F\r\n" + 
//								"\"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe\" " + line +"\r\n");
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
////						e.printStackTrace();
//					}
				}
			}
			break;
		}
	}

}
